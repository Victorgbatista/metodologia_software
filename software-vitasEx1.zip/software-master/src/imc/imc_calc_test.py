import pytest 
from imc_calc import *

@pytest.mark.parametrize("peso,altura,imc",[
    (70, 1.80, "normal"), (60,1.90, "magreza"), (90,1.70, "obesidade I"),   
    (200,1.70, "obesidade III")
])


def test_calc_imc_valores (peso,altura,imc):
    assert calc_imc(peso,altura) == pytest.approx(imc)

def test_calc_imc(): 
    assert calc_imc(70,1.80) == pytest.approx("normal")
    assert calc_imc(60,1.90) == pytest.approx("magreza")
    assert calc_imc(90,1.70) == pytest.approx("obesidade I")
    assert calc_imc(200,1.70) == pytest.approx("obesidade III")
   


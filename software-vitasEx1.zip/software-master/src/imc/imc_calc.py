def calc_imc(peso, altura): 
    imc = (peso/(altura*altura))
    
    if imc < 18.5 : 
        return("magreza")
    elif imc > 18.5 and imc < 24.9: 
        return("normal")
    elif imc > 25 and imc < 29.9  : 
        return("sobrepeso")
    elif imc > 30 and imc < 34.9: 
        return("obesidade I")
    elif imc > 35 and imc < 39.9:
        return("obesidade II")
    elif imc > 40:  
        return("obesidade III")

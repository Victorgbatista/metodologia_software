# arquivo npc_player.py
def get_npc_tipo() -> list:
    npc = ["dragon", "troll"]
    return npc

def get_npc_saude() -> dict:
    npc = {"dragon": 100, "troll": 70}
    return npc
import math

def calc_area_circulo(r):
    return math.pi * (r * r)
